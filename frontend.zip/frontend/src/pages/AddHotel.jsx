import React from 'react'
import ManageHotelForm from '../forms/ManageHotelForm/ManageHotelForm'

const AddHotel = () => {
  return (
    <ManageHotelForm/>
  )
}

export default AddHotel
