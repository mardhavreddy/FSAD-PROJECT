export const hotelTypes = [
    "Budget",
    "Boutique",
    "Luxury",
    "Ski Resort",
    "Business",
    "Family",
    "Romantic",
    "Hiking Resort",
    "Cabin",
    "Beach Resort",
    "Golf Resort",
    "Motel",
    "All Inclusive",
]

export const hotelFacilities = [
    "Free Wifi",
    "Parking",
    "Airport Shuttle",
    "Family Rooms",
    "Non-Smoking Rooms",
    "Outdoor Pool",
    "Spa",
    "Fitness Center",
]